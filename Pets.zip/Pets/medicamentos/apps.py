from django.apps import AppConfig


class MedicamentosConfig(AppConfig):
    name = 'medicamentos'
