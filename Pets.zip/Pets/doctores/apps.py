from django.apps import AppConfig


class DoctoresConfig(AppConfig):
    name = 'doctores'
