from django.db import models
from mascotas.models import Mascota
from doctores.models import Doctor
from medicamentos.models import Medicamento

# Create your models here.
class Visita_Medica(models.Model):
    id = models.AutoField(primary_key=True)
    fecha = models.DateField(blank= False, null= False)
    mascota_id = models.ForeignKey(Mascota, on_delete=models.CASCADE)
    doctor_id = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    motivo = models.CharField(max_length= 100, blank= False, null= False)
    diagnostico = models.TextField(blank= False, null= False)
    indicacion = models.TextField(blank= False, null= False)
    observacion = models.TextField(blank= False, null= False)
    valor = models.CharField(max_length= 100, blank= False, null= False)
    medicamento = models.ManyToManyField(Medicamento)