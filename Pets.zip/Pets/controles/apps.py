from django.apps import AppConfig


class ControlesConfig(AppConfig):
    name = 'controles'
