from django.apps import AppConfig


class mascotasConfig(AppConfig):
    name = 'mascotas'
