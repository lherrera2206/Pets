from django.db import models
from animales.models import Animal
from usuario.models import Usuario
from vacunas.models import Vacuna

# Create your models here.
class Mascota(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length= 100, blank= False, null= False)
    animal_id = models.ForeignKey(Animal, on_delete=models.CASCADE)
    raza = models.CharField(max_length= 100, blank= False, null= False)
    edad = models.CharField(max_length= 100, blank= False, null= False)
    peso = models.CharField(max_length= 100, blank= False, null= False)
    altura = models.CharField(max_length= 100, blank= True, null= True)
    usuario_id = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    vacuna = models.ManyToManyField(Vacuna)