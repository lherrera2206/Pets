from django.apps import AppConfig


class VacunasConfig(AppConfig):
    name = 'vacunas'
