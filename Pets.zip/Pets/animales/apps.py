from django.apps import AppConfig


class AnimalesConfig(AppConfig):
    name = 'animales'
